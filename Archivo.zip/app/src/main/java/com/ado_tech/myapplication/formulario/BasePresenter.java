package com.ado_tech.myapplication.formulario;

import android.content.Intent;

public interface BasePresenter {

    void onViewCreated(Intent intent);
}
